import { useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard, ListTodo, Settings, Plus, Search, Menu, X,
  CheckCircle2, Clock3, CircleDot, Trash2, Pencil, CalendarDays,
  TrendingUp, ClipboardList, Moon, Sun, Filter, Check, Sparkles,
  ArrowUpRight, RotateCcw, CircleHelp
} from "lucide-react";
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip
} from "recharts";

const STORAGE_KEY = "taskflow-tasks-v1";
const THEME_KEY = "taskflow-theme-v1";

const starterTasks = [
  { id: 1, title: "Complete React project", description: "Build the TaskFlow portfolio website.", dueDate: "2026-11-22", priority: "High", status: "In Progress", createdAt: "2026-11-18" },
  { id: 2, title: "Study Java programming", description: "Revise object-oriented programming concepts.", dueDate: "2026-11-21", priority: "Medium", status: "Pending", createdAt: "2026-11-18" },
  { id: 3, title: "Complete college assignment", description: "Finish the computer science assignment.", dueDate: "2026-11-20", priority: "High", status: "Completed", createdAt: "2026-11-17" },
  { id: 4, title: "Practice JavaScript", description: "Work through functions, arrays and objects.", dueDate: "2026-11-25", priority: "Low", status: "Pending", createdAt: "2026-11-17" }
];

function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved === null ? starterTasks : JSON.parse(saved);
  } catch {
    return starterTasks;
  }
}

function App() {
  const [tasks, setTasks] = useState(loadTasks);
  const [page, setPage] = useState("Dashboard");
  const [dark, setDark] = useState(() => localStorage.getItem(THEME_KEY) === "dark");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [modalTask, setModalTask] = useState(undefined);
  const [toast, setToast] = useState("");

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(THEME_KEY, dark ? "dark" : "light");
  }, [dark]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(timer);
  }, [toast]);

  function saveTask(task) {
    if (task.id) {
      setTasks(current => current.map(item => item.id === task.id ? task : item));
      setToast("Task updated successfully");
    } else {
      setTasks(current => [{ ...task, id: Date.now(), createdAt: new Date().toISOString().slice(0, 10) }, ...current]);
      setToast("New task added successfully");
    }
    setModalTask(undefined);
  }

  function updateStatus(id, status) {
    setTasks(current => current.map(task => task.id === id ? { ...task, status } : task));
    setToast("Task status updated");
  }

  function deleteTask(id) {
    if (!window.confirm("Are you sure you want to delete this task?")) return;
    setTasks(current => current.filter(task => task.id !== id));
    setToast("Task deleted");
  }

  function resetTasks() {
    if (!window.confirm("Restore the original demo tasks? Your current task list will be replaced.")) return;
    setTasks(starterTasks);
    setToast("Demo tasks restored");
  }

  const navItems = [
    { name: "Dashboard", icon: LayoutDashboard },
    { name: "My Tasks", icon: ListTodo },
    { name: "Settings", icon: Settings }
  ];

  return (
    <div className={`app-shell ${dark ? "dark" : ""}`}>
      <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><CheckCircle2 size={22} /></div>
          <span>TaskFlow</span>
          <button className="mobile-close icon-button" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X size={19} /></button>
        </div>

        <div className="nav-caption">WORKSPACE</div>
        <nav className="side-nav">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <button key={item.name} className={`nav-link ${page === item.name ? "active" : ""}`}
                onClick={() => { setPage(item.name); setSidebarOpen(false); }}>
                <Icon size={19} /><span>{item.name}</span>
                {item.name === "My Tasks" && <span className="nav-count">{tasks.length}</span>}
              </button>
            );
          })}
        </nav>

        <div className="sidebar-spacer" />
        <div className="sidebar-tip">
          <div className="tip-icon"><Sparkles size={17} /></div>
          <strong>Make today count</strong>
          <p>Small steps every day lead to big results.</p>
        </div>
        <div className="profile-mini">
          <div className="avatar">G</div>
          <div className="profile-copy"><strong>Guest User</strong><span>Demo workspace</span></div>
          <span className="online-dot" />
        </div>
        <div className="sidebar-foot">TASKFLOW · FRONTEND DEMO</div>
      </aside>

      {sidebarOpen && <button className="mobile-backdrop" onClick={() => setSidebarOpen(false)} aria-label="Close navigation" />}

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu icon-button" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu size={21} /></button>
            <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{page}</strong></div>
          </div>
          <div className="topbar-right">
            <span className="demo-pill"><span /> Guest demo</span>
            <button className="icon-button theme-button" onClick={() => setDark(value => !value)} aria-label="Toggle theme" title="Toggle theme">
              {dark ? <Sun size={19} /> : <Moon size={19} />}
            </button>
            <div className="avatar top-avatar">G</div>
          </div>
        </header>

        {page === "Dashboard" && <Dashboard tasks={tasks} onAdd={() => setModalTask(null)} onPage={setPage} onStatus={updateStatus} />}
        {page === "My Tasks" && <TasksPage tasks={tasks} onAdd={() => setModalTask(null)} onEdit={setModalTask} onDelete={deleteTask} onStatus={updateStatus} />}
        {page === "Settings" && <SettingsPage tasks={tasks} dark={dark} setDark={setDark} onReset={resetTasks} />}

        <footer className="main-footer">
          <span>© 2026 TaskFlow</span>
          <span>Made for getting things done <span className="footer-heart">♥</span></span>
        </footer>
      </main>

      {modalTask !== undefined && <TaskModal task={modalTask} onSave={saveTask} onClose={() => setModalTask(undefined)} />}
      {toast && <div className="toast"><Check size={17} />{toast}</div>}
    </div>
  );
}

function PageHeading({ eyebrow, title, description, action }) {
  return (
    <div className="page-heading">
      <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>
      {action}
    </div>
  );
}

function Dashboard({ tasks, onAdd, onPage, onStatus }) {
  const counts = {
    total: tasks.length,
    pending: tasks.filter(t => t.status === "Pending").length,
    progress: tasks.filter(t => t.status === "In Progress").length,
    completed: tasks.filter(t => t.status === "Completed").length
  };
  const completion = counts.total ? Math.round(counts.completed / counts.total * 100) : 0;
  const chartData = [
    { name: "Pending", value: counts.pending, color: "#f2ad52" },
    { name: "In Progress", value: counts.progress, color: "#8878e8" },
    { name: "Completed", value: counts.completed, color: "#43b98b" }
  ].filter(item => item.value > 0);
  const statCards = [
    { label: "Total tasks", value: counts.total, note: "All your tasks", icon: ClipboardList, tone: "violet" },
    { label: "Pending", value: counts.pending, note: "Waiting to start", icon: Clock3, tone: "amber" },
    { label: "In progress", value: counts.progress, note: "Currently working on", icon: CircleDot, tone: "blue" },
    { label: "Completed", value: counts.completed, note: "Successfully finished", icon: CheckCircle2, tone: "green" }
  ];
  const recent = [...tasks].slice(0, 5);

  return (
    <section className="page-content">
      <PageHeading eyebrow="OVERVIEW" title="Dashboard" description="Here's what's happening with your tasks today."
        action={<button className="primary-button" onClick={onAdd}><Plus size={18} /> Add new task</button>} />

      <div className="welcome-banner">
        <div className="welcome-decoration decoration-one" /><div className="welcome-decoration decoration-two" />
        <div className="welcome-content">
          <span className="welcome-label"><Sparkles size={14} /> YOUR PERSONAL WORKSPACE</span>
          <h2>A little progress each day<br className="desktop-break" /> adds up to big results.</h2>
          <p>Stay focused, keep organised, and make today productive.</p>
          <button className="banner-button" onClick={() => onPage("My Tasks")}>View my tasks <ArrowUpRight size={16} /></button>
        </div>
        <div className="banner-art"><div className="art-circle"><CheckCircle2 size={54} /></div><span className="art-spark spark-a">✦</span><span className="art-spark spark-b">✧</span></div>
      </div>

      <div className="section-title-row"><div><h2>Your activity</h2><p>A quick snapshot of your productivity</p></div><span className="today-label"><CalendarDays size={14} /> Today</span></div>
      <div className="stats-grid">
        {statCards.map(card => {
          const Icon = card.icon;
          return <article className="stat-card" key={card.label}>
            <div className={`stat-icon ${card.tone}`}><Icon size={21} /></div>
            <div className="stat-label">{card.label}</div><div className="stat-value">{card.value}</div><div className="stat-note">{card.note}</div>
          </article>;
        })}
      </div>

      <div className="dashboard-lower">
        <section className="surface-card recent-card">
          <div className="card-heading"><div><h2>Recent tasks</h2><p>Your latest task updates</p></div><button className="subtle-link" onClick={() => onPage("My Tasks")}>View all <ArrowUpRight size={15} /></button></div>
          {recent.length ? <div className="recent-list">{recent.map(task => <RecentTask key={task.id} task={task} onStatus={onStatus} />)}</div> : <EmptyState />}
        </section>

        <section className="surface-card progress-card">
          <div className="card-heading"><div><h2>Task progress</h2><p>How you're doing so far</p></div><div className="mini-icon"><TrendingUp size={17} /></div></div>
          <div className="progress-chart">
            {tasks.length ? <ResponsiveContainer width="100%" height={185}>
              <PieChart><Pie data={chartData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={77} paddingAngle={4} stroke="none">
                {chartData.map(entry => <Cell key={entry.name} fill={entry.color} />)}
              </Pie><Tooltip /></PieChart>
            </ResponsiveContainer> : <div className="chart-empty"><ClipboardList size={30} /><span>No tasks yet</span></div>}
            <div className="chart-center"><strong>{completion}%</strong><span>completed</span></div>
          </div>
          <div className="legend-list">{[
            ["Pending", counts.pending, "#f2ad52"], ["In progress", counts.progress, "#8878e8"], ["Completed", counts.completed, "#43b98b"]
          ].map(([label, value, color]) => <div className="legend-item" key={label}><span className="legend-dot" style={{ background: color }} /><span>{label}</span><strong>{value}</strong></div>)}</div>
        </section>
      </div>
    </section>
  );
}

function RecentTask({ task, onStatus }) {
  return <div className="recent-row">
    <div className={`task-check ${task.status === "Completed" ? "checked" : ""}`}>{task.status === "Completed" ? <Check size={14} /> : <span />}</div>
    <div className="recent-task-copy"><strong className={task.status === "Completed" ? "completed-title" : ""}>{task.title}</strong><span>{task.dueDate ? `Due ${formatDate(task.dueDate)}` : "No due date"}</span></div>
    <select className={`status-select status-${slug(task.status)}`} value={task.status} onChange={e => onStatus(task.id, e.target.value)} aria-label={`Status for ${task.title}`}>
      <option>Pending</option><option>In Progress</option><option>Completed</option>
    </select>
  </div>;
}

function TasksPage({ tasks, onAdd, onEdit, onDelete, onStatus }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [priorityFilter, setPriorityFilter] = useState("All");
  const [sort, setSort] = useState("newest");

  const filtered = useMemo(() => {
    const result = tasks.filter(task => {
      const term = search.toLowerCase();
      const matchesText = task.title.toLowerCase().includes(term) || task.description.toLowerCase().includes(term);
      return matchesText && (statusFilter === "All" || task.status === statusFilter) && (priorityFilter === "All" || task.priority === priorityFilter);
    });
    return result.sort((a, b) => sort === "due" ? (a.dueDate || "9999").localeCompare(b.dueDate || "9999") : sort === "oldest" ? a.id - b.id : b.id - a.id);
  }, [tasks, search, statusFilter, priorityFilter, sort]);

  return <section className="page-content">
    <PageHeading eyebrow="WORKSPACE" title="My tasks" description="Everything you need to do, all in one place."
      action={<button className="primary-button" onClick={onAdd}><Plus size={18} /> Create task</button>} />
    <div className="task-controls">
      <div className="search-field"><Search size={18} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tasks..." /></div>
      <div className="filter-control"><Filter size={16} /><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option>All</option><option>Pending</option><option>In Progress</option><option>Completed</option></select></div>
      <select className="plain-select" value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}><option value="All">All priorities</option><option>High</option><option>Medium</option><option>Low</option></select>
      <select className="plain-select sort-select" value={sort} onChange={e => setSort(e.target.value)}><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="due">Due date</option></select>
    </div>
    <div className="task-results-line"><span>Showing <strong>{filtered.length}</strong> of <strong>{tasks.length}</strong> tasks</span></div>
    <div className="task-grid">
      {filtered.map(task => <TaskCard key={task.id} task={task} onEdit={() => onEdit(task)} onDelete={() => onDelete(task.id)} onStatus={onStatus} />)}
    </div>
    {!filtered.length && <EmptyState title={tasks.length ? "No matching tasks" : "Your task list is empty"} description={tasks.length ? "Try changing your search or filters." : "Create your first task to get started."} />}
  </section>;
}

function TaskCard({ task, onEdit, onDelete, onStatus }) {
  return <article className="task-card">
    <div className="task-card-top"><span className={`priority-tag priority-${task.priority.toLowerCase()}`}><i />{task.priority} priority</span>
      <div className="task-card-actions"><button className="icon-button small" onClick={onEdit} title="Edit task"><Pencil size={16} /></button><button className="icon-button small delete-action" onClick={onDelete} title="Delete task"><Trash2 size={16} /></button></div>
    </div>
    <h3>{task.title}</h3><p className="task-description">{task.description || "No description added."}</p>
    <div className="task-card-bottom"><span className="due-date"><CalendarDays size={15} />{task.dueDate ? formatDate(task.dueDate) : "No due date"}</span>
      <select className={`status-select status-${slug(task.status)}`} value={task.status} onChange={e => onStatus(task.id, e.target.value)} aria-label="Update task status">
        <option>Pending</option><option>In Progress</option><option>Completed</option>
      </select>
    </div>
  </article>;
}

function TaskModal({ task, onSave, onClose }) {
  const [title, setTitle] = useState(task?.title || "");
  const [description, setDescription] = useState(task?.description || "");
  const [dueDate, setDueDate] = useState(task?.dueDate || "");
  const [priority, setPriority] = useState(task?.priority || "Medium");
  const [status, setStatus] = useState(task?.status || "Pending");
  const [error, setError] = useState("");

  function submit(event) {
    event.preventDefault();
    if (!title.trim()) { setError("Please enter a task title."); return; }
    onSave({ id: task?.id, title: title.trim(), description: description.trim(), dueDate, priority, status });
  }

  return <div className="modal-backdrop" onMouseDown={onClose}>
    <form className="task-modal" onSubmit={submit} onMouseDown={e => e.stopPropagation()}>
      <div className="modal-heading"><div><span className="eyebrow">{task ? "UPDATE YOUR WORK" : "ADD TO YOUR WORKSPACE"}</span><h2>{task ? "Edit task" : "Create a task"}</h2></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close"><X size={20} /></button></div>
      <label className="form-label">Task title <span>*</span><input autoFocus value={title} onChange={e => { setTitle(e.target.value); setError(""); }} placeholder="e.g. Finish web development assignment" maxLength={90} /></label>
      <label className="form-label">Description<textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Add a few details about this task..." rows={3} maxLength={400} /></label>
      <div className="form-two-col">
        <label className="form-label">Due date<input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} /></label>
        <label className="form-label">Priority<select value={priority} onChange={e => setPriority(e.target.value)}><option>Low</option><option>Medium</option><option>High</option></select></label>
      </div>
      <label className="form-label">Status<select value={status} onChange={e => setStatus(e.target.value)}><option>Pending</option><option>In Progress</option><option>Completed</option></select></label>
      {error && <p className="form-error">{error}</p>}
      <div className="modal-footer"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button type="submit" className="primary-button">{task ? "Save changes" : <><Plus size={17} /> Add task</>}</button></div>
    </form>
  </div>;
}

function SettingsPage({ tasks, dark, setDark, onReset }) {
  const completed = tasks.filter(t => t.status === "Completed").length;
  return <section className="page-content">
    <PageHeading eyebrow="PREFERENCES" title="Settings" description="Customise your workspace and manage your demo data." />
    <div className="settings-layout">
      <section className="surface-card settings-card">
        <div className="settings-section-heading"><div className="settings-symbol"><span className="avatar">G</span></div><div><h2>Guest profile</h2><p>This is a local demo workspace. No account is required.</p></div></div>
        <div className="settings-divider" />
        <div className="settings-row"><div><strong>Display name</strong><span>Guest User</span></div><span className="read-only-label">DEMO</span></div>
        <div className="settings-row"><div><strong>Workspace type</strong><span>Personal task manager</span></div><span className="read-only-label">LOCAL</span></div>
      </section>
      <section className="surface-card settings-card">
        <div className="settings-section-heading"><div className="settings-icon"><Sun size={19} /></div><div><h2>Appearance</h2><p>Choose the look that feels comfortable.</p></div></div>
        <div className="settings-divider" />
        <div className="settings-row"><div><strong>Dark theme</strong><span>Switch between light and dark appearance.</span></div><button className={`toggle-switch ${dark ? "on" : ""}`} onClick={() => setDark(!dark)} aria-label="Toggle dark theme"><span /></button></div>
      </section>
      <section className="surface-card settings-card">
        <div className="settings-section-heading"><div className="settings-icon purple-icon"><RotateCcw size={19} /></div><div><h2>Task data</h2><p>Your tasks are saved in this browser using LocalStorage.</p></div></div>
        <div className="settings-divider" />
        <div className="data-summary"><div><strong>{tasks.length}</strong><span>Total tasks</span></div><div><strong>{completed}</strong><span>Completed</span></div></div>
        <div className="settings-row reset-row"><div><strong>Restore sample tasks</strong><span>Replace your current list with the original examples.</span></div><button className="secondary-button" onClick={onReset}>Reset demo data</button></div>
      </section>
      <div className="demo-notice"><CircleHelp size={18} /><p><strong>About this version</strong>This is a frontend-only portfolio demo. It does not use a server, database, real login, or cloud sync. Your tasks stay in this browser on this device.</p></div>
    </div>
  </section>;
}

function EmptyState({ title = "Nothing here yet", description = "Your tasks will appear here when you add them." }) {
  return <div className="empty-state"><div className="empty-icon"><ClipboardList size={26} /></div><h3>{title}</h3><p>{description}</p></div>;
}

function slug(value) { return value.toLowerCase().replaceAll(" ", "-"); }
function formatDate(value) {
  if (!value) return "No due date";
  const date = new Date(`${value}T00:00:00`);
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export default App;
