# TaskFlow — Frontend Task Management App

TaskFlow is a responsive, frontend-only task management dashboard built with React and Vite. It is designed as a portfolio project and runs entirely in the browser.

## Features

- Guest demo workspace (no registration or login required)
- Dashboard with total, pending, in-progress and completed task counts
- Create, edit and delete tasks
- Update task status and priority
- Search tasks by title or description
- Filter by status and priority
- Sort by newest, oldest or due date
- Task progress doughnut chart
- Light and dark themes
- Responsive desktop and mobile navigation
- Browser persistence using LocalStorage
- Sample tasks on first launch

## Technology

- React
- Vite
- JavaScript
- CSS
- Lucide React icons
- Recharts
- Browser LocalStorage

## Run locally

1. Install Node.js (LTS) from https://nodejs.org/
2. Download or clone this repository.
3. Open the `taskflow` folder in VS Code.
4. Open the VS Code terminal.
5. Run:

```bash
npm install
npm run dev
```

6. Open the local URL printed in the terminal (usually http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

The production files are generated in the `dist` folder.

## Deploy to Vercel

1. Push this project to a GitHub repository.
2. Sign in to https://vercel.com/ and import the repository.
3. Vercel should detect Vite automatically.
4. Use `npm run build` as the build command and `dist` as the output directory.
5. Deploy.

No environment variables are required.

## Data and privacy notes

This version does **not** include a backend, MongoDB, Express, JWT authentication, or cloud sync. Tasks and theme preference are stored in the browser's LocalStorage on the current device and browser. Clearing browser site data can remove saved tasks. This is a demo/portfolio frontend, not a secure multi-user service.

## Main interactions

| Area | Function |
|---|---|
| Dashboard | Task totals, progress chart and recent tasks |
| My Tasks | Create, edit, delete, search, filter and sort |
| Settings | Theme preference and reset sample tasks |
| LocalStorage | Saves tasks and theme in the browser |

## Portfolio description

Built a responsive task management dashboard using React, Vite and CSS. Implemented task CRUD interactions, search, filtering, sorting, productivity statistics, a progress chart, theme switching and browser-based persistence with LocalStorage.

## Screenshots

Add your own screenshots here after running the project:

- `screenshots/dashboard.png`
- `screenshots/tasks.png`
- `screenshots/settings.png`
